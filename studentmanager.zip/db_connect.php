<?php 

$conn= new mysqli('sdb-s.hosting.stackcp.net','studentmanager-323037b5be','Tienpro01','studentmanager-323037b5be')or die("Could not connect to mysql".mysqli_error($con));
